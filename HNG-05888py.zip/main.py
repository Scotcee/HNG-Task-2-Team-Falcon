Output="[Hello world! Name HNGI7 Id language email]"
print ("hello world! My name is Joseph Ajemba with HNGI7 ID 05888 using phyton language for stage 2 task itzscotcee@gmail.com")